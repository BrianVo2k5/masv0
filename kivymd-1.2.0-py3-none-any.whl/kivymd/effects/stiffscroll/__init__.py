from .stiffscroll import StiffScrollEffect
